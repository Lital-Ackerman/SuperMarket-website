export class Cart{
    constructor(
        public cartId:number,
        public userId:number,
        public cartDate:Date,
        public isCompleted:number
    ){}
}

